To run the demo, you can open the file demo.html from the browser "File/Open..." menu.

Another option is to start the built-in Python HTTP server by

    python -m http.server

The default port is 8000. To specify another port:

    python -m http.server 8080

Then load http://localhost:<port>/demo.html in the browser address bar.

For more information please visit http://brython.info.